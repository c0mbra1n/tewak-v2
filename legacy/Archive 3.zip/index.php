<?php
header('Location: monitor.php');
exit;
?>